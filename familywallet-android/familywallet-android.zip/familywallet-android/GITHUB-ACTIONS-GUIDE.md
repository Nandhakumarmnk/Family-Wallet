# 📱 Build APK from GitHub — Phone-Friendly Guide

This zip contains everything needed to build an Android APK using GitHub Actions (free, no computer needed).

## What you'll do

1. Replace files in your existing GitHub repo with these
2. GitHub automatically builds the APK in the cloud (about 5 minutes)
3. Download the APK from GitHub
4. Install on your Android phone

---

## Step 1 — Empty your existing GitHub repo

Open github.com on your phone, go to your repository.

For each file in the repo:
1. Tap the file name
2. Tap the trash icon (🗑️) at the top right
3. Tap "Commit changes" at the bottom
4. Repeat for every file

If your repo has many files, this is the slow part. Keep going.

When the repo is empty, you'll see "This repository is empty" message.

---

## Step 2 — Upload these files

Stay on your repository page. Tap **"Add file"** → **"Upload files"**.

You need to upload these 8 items:

```
.github/             (folder — contains workflow)
src/                 (folder — contains the app code)
.gitignore
android-variables.gradle
ANDROID-12-TO-16.md
capacitor.config.json
index.html
package.json
README.md
vite.config.js
```

**Important about uploading on phone:** GitHub's mobile site requires you to upload files individually, but it accepts zip files extracted into folders. The easiest way:

**Option A — Use "GitHub" mobile app (recommended)**
Install GitHub from Play Store. Sign in. Open your repo. Tap "+" to add files. The app handles folders better than the website.

**Option B — Use the website**
Tap "Add file" → "Upload files" → tap the upload box. Your phone's file picker opens. **Tap and hold on a file to select multiple** then tap "Open" or "Done". Upload all root files first.

For the `.github/workflows/build-apk.yml` file specifically:
1. After uploading other files, tap "Add file" → "Create new file"
2. In the filename box, type: `.github/workflows/build-apk.yml`
3. (The slashes will create folders automatically)
4. Copy-paste the content of `.github/workflows/build-apk.yml` from the zip
5. Tap "Commit changes"

---

## Step 3 — Trigger the build

After all files are uploaded:

1. In your repo, tap the **"Actions"** tab at top
2. You should see "Build Android APK" listed
3. If it's already running (yellow circle) — wait
4. If not running — tap "Build Android APK" → "Run workflow" → "Run workflow"

**Wait 5–8 minutes.** GitHub is installing Android Studio in the cloud and building your APK.

You'll see a green checkmark when done ✅

---

## Step 4 — Download your APK

Two ways:

**Way 1 — From the build run**
1. Actions tab → tap the completed build (the one with green checkmark)
2. Scroll to bottom — you'll see "Artifacts" section
3. Tap **"FamilyWallet-APK"**
4. A zip downloads. Unzip it on phone — you'll find `app-debug.apk`

**Way 2 — From Releases (easier)**
1. On your repo's main page, tap **"Releases"** in right sidebar
2. Tap latest release (e.g., "FamilyWallet APK Build 1")
3. Under "Assets", tap **`app-debug.apk`** → it downloads directly

---

## Step 5 — Install on phone

1. Open your Files app → Downloads
2. Tap `app-debug.apk`
3. Phone shows "Install blocked" or "Unknown sources"
4. Tap **Settings** when prompted → enable **"Allow from this source"**
5. Go back, tap Install
6. Tap Open when done

🎉 FamilyWallet is now on your phone as a real installed app.

---

## After code changes

If you edit any file in GitHub (tap pencil icon), the workflow runs automatically — a new APK is built and added to Releases. Just re-download and reinstall.

---

## Troubleshooting

**Build failed (red X)**
- Tap the failed build → click on the red step → read the error
- Send me the error message and I'll fix it

**"Run workflow" button missing**
- Means workflow file isn't in the right place
- Check that the file path is exactly: `.github/workflows/build-apk.yml`

**APK won't install on phone — "App not installed"**
- Uninstall any old version first
- Make sure your phone has Android 12 or newer

**APK installs but shows blank white screen**
- Means web files weren't built before APK packaging
- The workflow handles this — try rebuilding

---

## What this APK includes

- Login & registration
- Family wallet with invite codes
- Personal & family transactions
- Daily backup banner
- Email backup (uses your phone's email app)
- Status emails to family members
- Trusted device management with OTP verification
- All data stored locally on your phone

Built for Android 12 → Android 16. Works on most phones from 2021 onwards.
